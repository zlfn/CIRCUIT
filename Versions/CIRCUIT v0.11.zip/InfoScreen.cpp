#include "Graphic.h"
#include "GameState.h"

int drawInfoScreen(Buffer buf, GameState state)
{
	drawText(buf, L"�׽�Ʈ", 0, 0, 100, Color::White);
	drawImage(buf, L"TileLR.gres", 20, 20);


	drawImage(buf, L"BackButton.gres", 68, 37);
	return 0;
}

int playInfoScreen(Buffer buf, GameState *state)
{
	return 0;
}